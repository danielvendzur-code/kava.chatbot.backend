globalThis.CX_CATALOGUES ||= {};
globalThis.CX_CATALOGUES.ravina = {
 "brand": "RAVINA",
 "domain": "ravina.cz",
 "operator": {
  "name": "ZV Capital s.r.o.",
  "ico": "09331221",
  "country": "CZ",
  "activeNoEnd": true,
  "aliases": [
   "mals.cz"
  ],
  "officialRegistry": "https://ares.gov.cz/ekonomicke-subjekty-v-be/rest/ekonomicke-subjekty/09331221"
 },
 "series": "s5",
 "segment": "fragrance",
 "lang": "cs",
 "country": "CZ",
 "currency": "CZK",
 "status": "SOURCE_PACKAGE_VERIFIED",
 "products": [
  {
   "id": "berry",
   "name": "APAR F001",
   "url": "https://ravina.cz/imitace-damske-parfemy-inspirovane-giorgio-armani-si/948-1096-imitace-damske-parfemy-apar-f001-inspirovane-armani-si.html#/1-objem-50_ml_standard",
   "priceAmount": 269,
   "price": "269 Kč",
   "currency": "CZK",
   "volume": "50 ml STANDARD",
   "category": "fragrance",
   "kind": "Parfém",
   "tags": [],
   "available": true,
   "isSample": false,
   "description": "Černý rybíz, růže a vanilka. Vůně APAR, nejde o originál jiné značky. Na e-shopu zvolte 50 ml STANDARD.",
   "reason": "Černý rybíz, růže a vanilka. Vůně APAR, nejde o originál jiné značky. Na e-shopu zvolte 50 ml STANDARD.",
   "photo": "/assets/s5/ravina/berry.jpg",
   "source": {
    "series": "s5",
    "url": "https://ravina.cz/imitace-damske-parfemy-inspirovane-giorgio-armani-si/948-1096-imitace-damske-parfemy-apar-f001-inspirovane-armani-si.html#/1-objem-50_ml_standard",
    "verifiedAt": "2026-11-15T15:47:54.232025+00:00",
    "sourceSha256": "6948f81eca2f7173f87ec2ddd7d8eddee18dd9d773a6559af75bfb4695c5da6e",
    "stock": "InStock",
    "stockEvidence": {
     "currency": "CZK",
     "scope": "OfficialPrestaShop exactselectedproduct-attribute publicJSON50mlSTANDARD, quantity>0andSkladem",
     "productId": 948,
     "variantId": 1096,
     "publisherAvailability": "Skladem",
     "quantity": 8,
     "variantSelectionRequired": true
    },
    "priceFrom": false,
    "priceEvidence": {
     "amount": 269,
     "currency": "CZK",
     "vatSource": "https://ravina.cz/imitace-damske-parfemy-inspirovane-giorgio-armani-si/948-1096-imitace-damske-parfemy-apar-f001-inspirovane-armani-si.html#/1-objem-50_ml_standard",
     "vatEvidence": "OfficialselectedPrestaShop retailprice_amount269CZK, tax-included consumerdisplay; no price-range/otherpack substitution."
    },
    "packEvidence": {
     "pack": "50 ml STANDARD",
     "scope": "Explicit published product pack, not shipping weight."
    },
    "variantSelectionRequired": true,
    "categoryLocked": true,
    "kindLocked": true,
    "photoUrl": "https://ravina.cz/2042-large_default/imitace-damske-parfemy-apar-f001-inspirovane-armani-si.jpg",
    "photoEvidence": {
     "id": "berry",
     "file": "berry.jpg",
     "url": "https://ravina.cz/2042-large_default/imitace-damske-parfemy-apar-f001-inspirovane-armani-si.jpg",
     "sha256": "de8a19f882a0b33b4118abca1db0c3216fba04db74058b2dc098fae92c0e845f",
     "bytes": 46046,
     "originalBytes": true,
     "verifiedAt": "2026-11-15T22:52:14.813828+00:00",
     "width": 1000,
     "height": 1000
    },
    "fragrance": {
     "notes": [
      "listy černého rybízu",
      "růže",
      "frézie",
      "pačuli",
      "vanilka",
      "dřevité tóny"
     ],
     "officialFamilies": [],
     "intensity": null,
     "occasion": null,
     "concentrationDisplay": "Parfém",
     "notesEvidence": {
      "url": "https://ravina.cz/imitace-damske-parfemy-inspirovane-giorgio-armani-si/948-1096-imitace-damske-parfemy-apar-f001-inspirovane-armani-si.html#/1-objem-50_ml_standard",
      "sourceText": "Vonné tóny: listy černého rybízu, růže, frézie, pačuli, vanilka, dřevité tóny",
      "originalSourceText": "🌺 Imitace dámského parfému Armani Si – sladká elegance pro moderní ženu 🍇 Květinově-ovocná vůně s dotekem vanilky Objevte neodolatelnou imitaci ikonického parfému Armani Si, která v sobě spojuje ženskou smyslnost a přirozenou eleganci. Vůně se otevírá šťavnatými tóny listů černého rybízu, které přecházejí do opojného srdce z růže a frézie. Základ pak tvoří teplé dřevité tóny s vanilkou a pačuli, díky nimž je vůně dlouhotrvající a výrazná. Tato kombinace vytváří smyslnou a nezapomenutelnou kompozici pro každou příležitost. 💡 Proč si ji zamilujete? ✓ Věrně inspirováno vůní Armani Si ✓ Smyslná květinově-ovocná kombinace ✓ Ideální na denní nošení i večerní příležitosti ✓ Dlouhotrvající výdrž a výrazný charakter ✓ Skvělý poměr kvality a ceny 🌿 Krása s respektem k přírodě Tato imitace parfému je vyrobena s ohledem na životní prostředí. Kvalitní složky, šetrná výroba a dostupná cena dělají z této vůně ideální volbu pro ženy, které chtějí vonět luxusně bez kompromisů.🌸 Imitace dámského parfému Armani Si – květinově-ovocná vůně plná ženskosti Elegantní a smyslná vůně, která je inspirovaná ikonickým parfémem Armani Si. Tato imitace zaujme už v prvním momentě sladkým nádechem černého rybízu, následuje romantické srdce z růže a frézie a vše uzavírá teplý základ z pačuli, vanilky a dřevitých tónů. Výsledkem je sofistikovaná vůně, která dokonale podtrhne ženský půvab – od každodenního nošení až po slavnostní večery. ✅ Klíčové vlastnosti: ✓ Květinově-ovocná vůně s orientálními akordy ✓ Inspirace: Armani Si ✓ Hlava: listy černého rybízu ✓ Srdce: růže, frézie ✓ Základ: pačuli, vanilka, dřevité tóny ✓ Vhodná na denní i večerní nošení ✓ Dlouhotrvající výdrž ✓ Smyslná, elegantní a ženská ✓ Skvělý poměr ceny a kvality ✓ Ideální volba pro milovnice sladších vůní s hloubkou",
      "sourceLanguage": "cs",
      "scope": "Published product sensory descriptors only, not INCI or inferred ingredient percentages.",
      "noteFormMapping": [
       {
        "display": "listy černého rybízu",
        "sourceFragments": [
         "listy černého rybízu"
        ]
       },
       {
        "display": "růže",
        "sourceFragments": [
         "růže"
        ]
       },
       {
        "display": "frézie",
        "sourceFragments": [
         "frézie"
        ]
       },
       {
        "display": "pačuli",
        "sourceFragments": [
         "pačuli"
        ]
       },
       {
        "display": "vanilka",
        "sourceFragments": [
         "vanilka"
        ]
       },
       {
        "display": "dřevité tóny",
        "sourceFragments": [
         "dřevité tóny"
        ]
       }
      ],
      "qualification": "Flatpublishedprimarysensorynotes; F163ambiguousbasewording not expanded into inventedmusk. No measuredintensity/lasting/occasion guarantee."
     }
    },
    "complementForProductUrls": [],
    "excludedClaims": [
     "No medicinal/skin/allergy/safety/duration guarantees, numerical note strength, invented budget or cart integration."
    ],
    "usagePurpose": "personal-inspired-fragrance",
    "scent": "Černý rybíz, růže a vanilka",
    "identityDisclosure": "Own APAR inspiredfragrance, not designeroriginal or guaranteedidenticalsmell.",
    "photoQualification": "Original official productgallery. Selected50mlSTANDARD publicSKU. Publisher altlegendusesPREMIUM inconsistently; actualphoto APAR50ml labelhasnoPREMIUM assertion. Gallerymayinclude separatedesignerinspirationinset, not soldasdesigneroriginal.",
    "selectionTraits": {
     "fragranceDirection": "berry",
     "fragranceProfile": "berry"
    },
    "selectionTraitsEvidence": {
     "url": "https://ravina.cz/imitace-damske-parfemy-inspirovane-giorgio-armani-si/948-1096-imitace-damske-parfemy-apar-f001-inspirovane-armani-si.html#/1-objem-50_ml_standard",
     "sourceText": "Vonné tóny: listy černého rybízu, růže, frézie, pačuli, vanilka, dřevité tóny",
     "navigationLabel": "Černý rybíz, růže a vanilka",
     "navigationGroupingIsNotOfficialFragranceFamily": true
    }
   }
  },
  {
   "id": "lily",
   "name": "APAR F065",
   "url": "https://ravina.cz/378-1-damsky-parfem-apar-f065-standard-inspirovano-abercrombie-fitch-8.html#/1-objem-50_ml_standard",
   "priceAmount": 269,
   "price": "269 Kč",
   "currency": "CZK",
   "volume": "50 ml STANDARD",
   "category": "fragrance",
   "kind": "Parfém",
   "tags": [],
   "available": true,
   "isSample": false,
   "description": "Citrusy, lilie a pižmový základ. Vůně APAR, nejde o originál jiné značky. Na e-shopu zvolte 50 ml STANDARD.",
   "reason": "Citrusy, lilie a pižmový základ. Vůně APAR, nejde o originál jiné značky. Na e-shopu zvolte 50 ml STANDARD.",
   "photo": "/assets/s5/ravina/lily.jpg",
   "source": {
    "series": "s5",
    "url": "https://ravina.cz/378-1-damsky-parfem-apar-f065-standard-inspirovano-abercrombie-fitch-8.html#/1-objem-50_ml_standard",
    "verifiedAt": "2026-11-15T15:47:56.271179+00:00",
    "sourceSha256": "f60c61049fc6a0975f27c1b7ebd9d3c8583ad07ceab6dd515b43805d4629b387",
    "stock": "InStock",
    "stockEvidence": {
     "currency": "CZK",
     "scope": "OfficialPrestaShop exactselectedproduct-attribute publicJSON50mlSTANDARD, quantity>0andSkladem",
     "productId": 378,
     "variantId": 1,
     "publisherAvailability": "Skladem",
     "quantity": 3,
     "variantSelectionRequired": true
    },
    "priceFrom": false,
    "priceEvidence": {
     "amount": 269,
     "currency": "CZK",
     "vatSource": "https://ravina.cz/378-1-damsky-parfem-apar-f065-standard-inspirovano-abercrombie-fitch-8.html#/1-objem-50_ml_standard",
     "vatEvidence": "OfficialselectedPrestaShop retailprice_amount269CZK, tax-included consumerdisplay; no price-range/otherpack substitution."
    },
    "packEvidence": {
     "pack": "50 ml STANDARD",
     "scope": "Explicit published product pack, not shipping weight."
    },
    "variantSelectionRequired": true,
    "categoryLocked": true,
    "kindLocked": true,
    "photoUrl": "https://ravina.cz/2973-large_default/damsky-parfem-apar-f065-standard-inspirovano-abercrombie-fitch-8.jpg",
    "photoEvidence": {
     "id": "lily",
     "file": "lily.jpg",
     "url": "https://ravina.cz/2973-large_default/damsky-parfem-apar-f065-standard-inspirovano-abercrombie-fitch-8.jpg",
     "sha256": "998465e7c4beb5c96430f414ff33258d6aa9fdfd74ce5162204f8f94c67fafe2",
     "bytes": 43937,
     "originalBytes": true,
     "verifiedAt": "2026-11-15T22:52:15.059201+00:00",
     "width": 1000,
     "height": 1000
    },
    "fragrance": {
     "notes": [
      "citrusy",
      "lilie",
      "frézie",
      "fialka",
      "vanilka",
      "pižmo"
     ],
     "officialFamilies": [],
     "intensity": null,
     "occasion": null,
     "concentrationDisplay": "Parfém",
     "notesEvidence": {
      "url": "https://ravina.cz/378-1-damsky-parfem-apar-f065-standard-inspirovano-abercrombie-fitch-8.html#/1-objem-50_ml_standard",
      "sourceText": "Vonné tóny: citrusy, lilie, frézie, fialka, vanilka, pižmo",
      "originalSourceText": "Květinově - ovocná vůně Osvěžující ovocná-květinová vůně, která se dokáže přizpůsobit jakémukoli ročnímu období a každému počasí. V úvodu kompozice zaujme jasnými tóny citrusů, které jsou později zjemněny květinovými akcenty. Fascinující spojení lilií s jemnými tóny frézie a fialky je doplněno vanilkovo-pižmovým základem, dodává kompozici neuvěřitelně ženský charakter. Tyto parfémy podtrhnou váš styl a dodají mu eleganci i smyslnost. Vůně pro každou ženu Eau de parfum s ovocně-květinovou vůní. Zajistí vám svěžest a radost každý den. Jemně sladkou esenci rozbijí ovocné tóny. Díky květinovým vůním se celek stává pudrovým a jemným. Tuto vůni si zamiluje každá citlivá a energická žena. Tato jedinečná, esenciální vůně vás bude provázet každý den a dá vám pocit jistoty v každé situaci.",
      "sourceLanguage": "cs",
      "scope": "Published product sensory descriptors only, not INCI or inferred ingredient percentages.",
      "noteFormMapping": [
       {
        "display": "citrusy",
        "sourceFragments": [
         "citrusů"
        ]
       },
       {
        "display": "lilie",
        "sourceFragments": [
         "lilií"
        ]
       },
       {
        "display": "frézie",
        "sourceFragments": [
         "frézie"
        ]
       },
       {
        "display": "fialka",
        "sourceFragments": [
         "fialky"
        ]
       },
       {
        "display": "vanilka",
        "sourceFragments": [
         "vanilkovo"
        ]
       },
       {
        "display": "pižmo",
        "sourceFragments": [
         "pižmovým"
        ]
       }
      ],
      "qualification": "Flatpublishedprimarysensorynotes; F163ambiguousbasewording not expanded into inventedmusk. No measuredintensity/lasting/occasion guarantee."
     }
    },
    "complementForProductUrls": [],
    "excludedClaims": [
     "No medicinal/skin/allergy/safety/duration guarantees, numerical note strength, invented budget or cart integration."
    ],
    "usagePurpose": "personal-inspired-fragrance",
    "scent": "Citrusy, lilie a pižmový základ",
    "identityDisclosure": "Own APAR inspiredfragrance, not designeroriginal or guaranteedidenticalsmell.",
    "photoQualification": "Original official productgallery. Selected50mlSTANDARD publicSKU. Publisher altlegendusesPREMIUM inconsistently; actualphoto APAR50ml labelhasnoPREMIUM assertion. Gallerymayinclude separatedesignerinspirationinset, not soldasdesigneroriginal.",
    "selectionTraits": {
     "fragranceDirection": "lily",
     "fragranceProfile": "lily"
    },
    "selectionTraitsEvidence": {
     "url": "https://ravina.cz/378-1-damsky-parfem-apar-f065-standard-inspirovano-abercrombie-fitch-8.html#/1-objem-50_ml_standard",
     "sourceText": "Vonné tóny: citrusy, lilie, frézie, fialka, vanilka, pižmo",
     "navigationLabel": "Citrusy, lilie a pižmový základ",
     "navigationGroupingIsNotOfficialFragranceFamily": true
    }
   }
  }
 ],
 "revenue": {
  "year": 2024,
  "publishedBand": "1–3 mil. Kč",
  "currency": "CZK",
  "source": "https://www.chytryrejstrik.cz/ico-09331221/zv-capital-s-r-o",
  "sourceType": "Secondaryhistoricalband",
  "latestExact2025": "UNKNOWN"
 },
 "size": "PREFERRED_HISTORICAL_BAND_LATEST_EXACT_UNKNOWN",
 "interest": "NOT_ESTABLISHED",
 "notes": [
  "Two representative verifiedAPARformulas only: F001/F06550mlSTANDARD269CZK, not a claimonlytwoavailableinstore.",
  "F219/F163 secondgalleryphotos depict onlydesigneroriginals and areexcludedfromrecommendations. TheirgenericAPARcoversrepeat F001pixels, not used toinflatephotographicrepresentation.",
  "F001officialownAPAR50mlphoto;F065officialpairphoto ownAPAR+separatedesignerinspiration, visibleownAPARnotoriginaldisclosure. Twoactualdifferentpixelphotos.",
  "F002/F271OutOfStockexcluded. MALSsame09331221operatoronecompany. MAINbrandguard/integration/livePreview/commercialfitreviewrequired."
 ]
};
